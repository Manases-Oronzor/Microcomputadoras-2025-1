Simple MicroPython and CircuitPython projects

See https://iosoft.blog for details.